(function(){
    "use strict";
    if( document.getElementsByClassName("ts-full-screen").length ) {
        document.getElementsByClassName("ts-full-screen")[0].style.height = window.innerHeight + "px";
    }
})();